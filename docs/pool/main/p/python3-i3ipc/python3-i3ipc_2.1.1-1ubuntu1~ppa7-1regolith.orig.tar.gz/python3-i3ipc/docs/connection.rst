Connection
==========

.. autoclass:: i3ipc.Connection
   :members:
   :undoc-members:
