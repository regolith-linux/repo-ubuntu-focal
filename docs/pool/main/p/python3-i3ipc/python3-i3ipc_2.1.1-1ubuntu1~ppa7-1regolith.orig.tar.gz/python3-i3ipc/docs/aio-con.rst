aio.Con
=======

.. autoclass:: i3ipc.aio.Con
   :members:
   :undoc-members:
   :inherited-members:
