Replies
=======

.. autoclass:: i3ipc.CommandReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.VersionReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.BarConfigReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.OutputReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.InputReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.SeatReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.WorkspaceReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.TickReply
   :members:
   :undoc-members:

.. autoclass:: i3ipc.ConfigReply
   :members:
   :undoc-members:
