Con
===

.. autoclass:: i3ipc.Con
   :members:
   :undoc-members:

.. autoclass:: i3ipc.Rect
   :members:
   :undoc-members:

.. autoclass:: i3ipc.Gaps
   :members:
   :undoc-members:
